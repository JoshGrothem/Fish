package com.example.fish;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    //ANIMATION IS SPLIT INTO TWO THREADS:
    //          CALCULATING MOVEMENT
    //          FISH TANK UPDATES: UI THREAD
    private Thread calculateMovementThread;

    // FISH TANK ELEMENTS AND PROPERTIES
    private static ImageView fishImageView1;
    private static Fish mFish1;

    private static int tankWidth;
    private static int tankHeight;
    private FrameLayout fishTankLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //TASK 2: CREATE REFERENCES TO THE FRAME LAYOUT CONTAINER
        fishTankLayout = (FrameLayout) findViewById(R.id.container);

        //TASK 4: GET THE DIMENSIONS OF THE SCREEN TO USE FOR TH TANK SIZE
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        tankWidth = size.x + 400;
        tankHeight = size.y;

        //TASK 2: INSTANTIATE A FISH
        int initialXPosition = 0;
        int initialYPosition = 0;
        mFish1 = new Fish(initialXPosition, initialYPosition, Fish.IsSwimming, tankWidth, tankHeight, 9);

        //TASK 3: BUILD THE TANK ELEMENTS
        buildTank();

        //        AND ANIMATE THE MOVEMENT
        calculateMovementThread = new Thread(calculateMovement);

        //TASK 5: START THE THREAD
        calculateMovementThread.start();
    }


    private void buildTank() {
        //TASK 1: CREATE A LAYOUT INFLATER TO
        //        ADD VISUAL VIEWS TO THE LAYOUT
        LayoutInflater layoutInflater;
        layoutInflater = (LayoutInflater)
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //TASK 2: ADD THE FOLIAGE
        ImageView foliageImageView = (ImageView)
                layoutInflater.inflate(R.layout.foliage_layout, null);
        foliageImageView.setScaleX((float) 1.3);
        foliageImageView.setScaleY((float) 1.3);
        foliageImageView.setX((float) 0);
        //foliageImageView.setY((float) 0);
        foliageImageView.setY((float) 100);
        foliageImageView.setAlpha((float) .90);
        fishTankLayout.addView(foliageImageView, 0);

        //TASK 3: ADD THE VIRTUAL FISH
        fishImageView1 = (ImageView) layoutInflater.inflate(R.layout.fish_image, null);
        fishImageView1.setScaleX((float) .3);
        fishImageView1.setScaleY((float) .1);
        fishImageView1.setX(mFish1.x);
        fishImageView1.setY(mFish1.y);
        fishTankLayout.addView(fishImageView1, 0);


    }

    //******************* RUNNABLE **********************
    private Runnable calculateMovement = new Runnable() {
        private static final int DELAY = 100;

        public void run() {
            try {
                while (true) {
                    mFish1.move();

                    Thread.sleep(DELAY);
                    updateTankHandler.sendEmptyMessage(0);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };

    //***** HANDLER FOR UPDATING THE FISH BETWEEN SLEEP DELAYS ******

    public static Handler updateTankHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(android.os.Message msg) {

            //TASK 1: FACE THE FISH1 IN THE CORRECT DIRECTION
            fishImageView1.setScaleX((float) (.3 * mFish1.getFacingDirection()));

            //TASK 2: SET THE FISH1 AT THE CORRECT XY LOCATION
            fishImageView1.setX((float) mFish1.x);
            fishImageView1.setY((float) mFish1.y);
        }
    };
}
